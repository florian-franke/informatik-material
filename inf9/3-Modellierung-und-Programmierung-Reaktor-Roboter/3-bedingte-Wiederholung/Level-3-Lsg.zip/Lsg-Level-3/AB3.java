import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class AB3 extends Roboter
{

    /*#
     * Aufgabe 1: Feuer loeschen
     */
    public void loesche() {
        einsVor();
        aufnehmen();
        vorBisFeuer();
        benutze("Feuerloescher");
       // Hier fehlt noch was:
    }

    /*#
     * Aufgaben 3 & 4: Vor bis zum Feuer (wo auch immer das ist)
     */
    public void vorBisFeuer() 
    {
        while(!istVorne("Feuer")) {
            einsVor();
        }
    }

    /*#
     * Aufgabe 5: Feuersbrunst loeschen
     */
    // Hier kommt deine Methode loescheReihe() hin:
    public void loescheReihe(){
        einsVor();
        aufnehmen();
        vorBisFeuer();
        while(istVorne("Feuer")){
            benutze("Feuerloescher");
            einsVor();
        }
    }

    /*#
     * Aufgabe 6: Teste Reichweite eines Feuerloeschers
     */
    // Hier kommt die Methode testeReichweite() hin:
    public void testeReichweite(){
        einsVor();
        dreheLinks();
        einsVor();
        aufnehmen();  
        dreheUm();
        einsVor();
        einsVor();
        dreheLinks();
        while(getAnzahl("Feuerloescher")>=1){
            benutze("Feuerloescher");
            einsVor();
        }
    }


    /*#
     * Aufgabe 7: Feuerloescher einsammeln
     */
    public void sammleLoescher() 
    {
        while(istVorneFrei()){
            einsVor();
            dreheLinks();
            einsVor();
            aufnehmen();
            dreheUm();
            einsVor();
            dreheLinks();
            einsVor();
        }
        // Hier bitte deinen Quelltext einf�gen
    }  

    /*#
     * Hilfsmethode fuer Aufgabe 8
     */
    public void laufeBisWand() {
        // Hier bitte deinen Quelltext einf�gen
        while(istVorneFrei()){
            einsVor();
        }
    }

    /*#
     * Aufgabe 8: Homerun
     */
    public void laufeBisSackgasse() {
        einsVor();
        while(!istWandLinks()){
            dreheLinks();
            laufeBisWand();
        }
        // Hier bitte deinen Quelltext einf�gen
    }

    /*#
     * Einsatz 3: Bitte den Namen nicht aendern!
     */
    public void einsatz3() {
        // Hier bitte deinen Quelltext einf�gen
    }
}